// pages/user/renzheng/renzheng.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imagestatus: true,
    image1: '',
    image2: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.request({
      url: app.globalData.requestUrl + '/index/identity/getIndentity',
      header: {
        'content-type': ''
      },
      method: 'POST',
      data: {
        mem_id: app.globalData.openid,
      },
      success: function (res) {
        console.log(res, app.globalData.openid)
        that.setData({
          card: res.data.result.card,
          image1: res.data.result.image1,
          image2: res.data.result.image2,
          name: res.data.result.name,
          telephone: res.data.result.telephone,
          status: res.data.result.status
        })
      }
    })
  },
  chooseImg: function () {
    var _this = this;

    wx.chooseImage({

      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        //预览时的图片数组（暂时无用）

        _this.setData({
          image1: res.tempFilePaths.join(''),
          image_s: res.tempFiles
        })
        wx.showModal({
          title: '图片',
          content: '确认上传此图片',
          success: function (res) {
            if (res.confirm) {

              wx.uploadFile({
                url: 'https://cool.1peng.com.cn/xcx/wxapp/public/index/identity/addImage', //接口
                filePath: _this.data.image1,
                name: 'image1',
                formData: {
                  'user': 'test'
                },
                success: function (res) {
                  var obj = JSON.parse(res.data)
                  console.log(obj.res)
                  _this.setData({
                    image1: obj.res
                  })
                },
                fail: function (error) {
                  console.log(error);
                }
              })



            } else {
              console.log('弹框后点取消', '222')
              _this.setData({
                image1: [],
                image_s: []
              })
            }
          }
        })


      }
    })
  },
  chooseImg2: function () {
    var _this = this;
    wx.chooseImage({

      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths;
        //预览时的图片数组（暂时无用）


        _this.setData({
          image2: res.tempFilePaths.join(''),
          image_s: res.tempFiles
        })
        wx.showModal({
          title: '图片',
          content: '确认上传此图片',
          success: function (res) {
            if (res.confirm) {

              wx.uploadFile({
                url: 'https://cool.1peng.com.cn/xcx/wxapp/public/index/identity/addImage', //接口
                filePath: _this.data.image1,
                name: 'image1',
                formData: {
                  'user': 'test'
                },
                success: function (res) {
                  var obj = JSON.parse(res.data)
                  console.log(obj.res)
                  _this.setData({
                    image2: obj.res
                  })
                },
                fail: function (error) {
                  console.log(error);
                }
              })




            } else {
              console.log('弹框后点取消', '222')
              _this.setData({
                image2: '',
                image_s: ''
              })
            }
          }
        })


      }
    })
  },
  //姓名
  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  //身份证
  getUser: function (e) {
    this.setData({
      card: e.detail.value
    })
  },
  //姓名
  getPhone: function (e) {
    this.setData({
      telephone: e.detail.value
    })
  },
  deleteImg1:function(){
    this.setData({
      image1:''
    })
  },
  deleteImg2: function () {
    this.setData({
      image2: ''
    })
  },
  btn: function (imgs) {
    var that = this
    //提交数据
    if (!that.data.name) {
      wx.showToast({
        title: '请输入姓名',
      });
    } else if (!that.data.telephone) {
      wx.showToast({
        title: '请输入电话',
      });
    } else if (!that.data.card) {
      wx.showToast({
        title: '请输入身份证号',
      });
    } else {
      var that = this
      var data = {
        mem_id: app.globalData.openid,
        name: that.data.name,
        card: that.data.card,
        telephone: that.data.telephone,
        image1: that.data.image1,
        image2: that.data.image2
      }
      console.log(data)

      wx.request({
        url: 'https://cool.1peng.com.cn/xcx/wxapp/public/index/identity/addIndentity',
        data: data,
        method: 'post',
        header: {
          'content-type': ''
        },
        success: function (res) {
          console.log(res)
          if (res.data.statuscode == 1) {
            // console.log('111')
            wx.showToast({
              title: '提交成功',
              icon: 'success',
              duration: 2000,
              mask: true,
              success: function () {
                // wx.reLaunch({
                //   url: '/pages/user/user',
                // })
              }
            })
          }else{
            wx.showToast({
              title: '已修改',
              icon: 'success',
              duration: 2000,
              mask: true,
              success: function () {
                // wx.reLaunch({
                //   url: '/pages/user/user',
                // })
              }
            })
          }
          // var pages = getCurrentPages();             //  获取页面栈
          // var currPage = pages[pages.length - 1];    // 当前页面
          // var prevPage = pages[pages.length - 3];    // 上一个页面

          // wx.navigateBack({
          //   delta: 1
          // })
        }
      })
    }

  },



  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})