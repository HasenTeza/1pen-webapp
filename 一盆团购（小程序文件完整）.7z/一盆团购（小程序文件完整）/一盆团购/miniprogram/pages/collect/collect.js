// pages/collect/collect.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    // nav_status: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this
    // console.log(app.globalData.bis_id,app.globalData.openid,that.data.page)
 
    that.shoucang()

  },
   //普通商品详情
  details: function (e) {
    console.log(e.currentTarget.dataset.status)
    if (e.currentTarget.dataset.status === '未拼团'){
      wx: wx.navigateTo({
        url: '/pages/pro_detail/pro_detail?pro_id=' + e.currentTarget.dataset.pro_id,

      })
    }else{
      wx: wx.navigateTo({
        url: '/pages/pro_detail1/pro_detail?pro_id=' + e.currentTarget.dataset.pro_id,

      })
    }
    
  },
  shoucang:function(){
    var that = this
    //商品收藏
    wx.request({
      url: app.globalData.requestUrl + '/index/procollect/proCollectInfo',
      header: {
        'content-type': ''
      },
      data: {
        bis_id: app.globalData.bis_id,
        mem_id: app.globalData.openid,
        page: that.data.page
      },
      method: 'POST',
      success: function (res) {
        console.log(res, '获取收藏数据')
        if (res.data.result) {
          that.setData({
            collect: res.data.result
          })
        } else {
          that.setData({
            collect: []
          })
        }
      }
    })
  },
  //取消
  quxiao: function (e) {
    var that = this
    console.log(e.currentTarget.dataset.collect_id)
    wx.request({
      url: app.globalData.requestUrl + '/index/procollect/deleteCollect',
      header: {
        'content-type': ''
      },
      data: {
        bis_id: app.globalData.bis_id,
        mem_id: app.globalData.openid,
        id: e.currentTarget.dataset.collect_id
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data.message,'普通商品取消收藏')

        that.shoucang()
      }
    })
  },
  //下拉刷新
  onPullDownRefresh: function (options) {
    var that = this
    this.setData({
      page: 1
    })
    that.shoucang()
    
    wx.hideNavigationBarLoading() //完成停止加载
    wx.stopPullDownRefresh() //停止下拉刷新
  },


 onReachBottom: function () {    //上拉事件
    var that = this;

      // 显示加载图标
      wx.showLoading({
        title: '玩命加载中',
      })
      // 页数+1
      var page = this.data.page;
      page++;
      //更改data
      that.setData({
        page: page
      })
      //普通收藏
      wx.request({
        url: app.globalData.requestUrl + '/index/procollect/proCollectInfo',
        header: {
          'content-type': ''
        },
        data: {
          bis_id: app.globalData.bis_id,
          mem_id: app.globalData.openid,
          page: that.data.page
        },
        method: 'POST',
        success: function (res) {
          console.log(that.data.page)
          //定义数组
          var collect_data_list = that.data.collect;
          // console.log(res.data)
          // console.log(res.data.result)
          // console.log(res.data.result.length)
          if (res.data.result) {
            for (var i = 0; i < res.data.result.length; i++) {
              //添加新的
              collect_data_list.push(res.data.result[i]);
            }

            // 设置数据
            that.setData({
              collect: collect_data_list
            })
            // 隐藏加载框
            wx.hideLoading();
            wx.stopPullDownRefresh()
          } else {
            // 隐藏加载框
            wx.hideLoading();
            wx.stopPullDownRefresh()
          }

        }
      })
   
  }
  
})