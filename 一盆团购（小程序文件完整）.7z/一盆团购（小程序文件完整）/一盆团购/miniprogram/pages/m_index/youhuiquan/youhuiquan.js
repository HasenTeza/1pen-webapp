// pages/m_index/youhuiquan/youhuiquan.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.youhuiquan()
  },
  //获取优惠券
  youhuiquan: function() {
    var that = this
    wx.request({
      url: app.globalData.requestUrl + '/index/couponcolumn/getAllCouponColumn',
      header: {
        'content-type': ''
      },
      method: 'POST',
      data: {
        bis_id: app.globalData.bis_id,
        member: app.globalData.openid
      },
      success: function(res) {
        that.setData({
          youhuiquan: res.data.result
        })
      }
    })
  },
  //点击领取
  cou_id: function(e) {
    // console.log(e.currentTarget.dataset.cou_id)
    var that = this
    wx.request({
      url: app.globalData.requestUrl + '/index/couponcolumn/addCouponColumn',
      header: {
        'content-type': ''
      },
      method: 'POST',
      data: {
        bis_id: app.globalData.bis_id,
        member: app.globalData.openid,
        column_id: e.currentTarget.dataset.cou_id
      },
      success: function(res) {
        console.log(res)
        
        if (res.data.statuscode === 1) {
          that.youhuiquan()
          wx.showToast({
            title: '已领取',
            icon: 'succes',
            duration: 1000,
            mask: true
          })
        } else if (res.data.statuscode === 0) {
          wx.showToast({
            title: '该代金券已被领取',
            // icon: 'loading',
            duration: 1000,
            mask: true
          })
        } else {
          wx.showToast({
            title: '该代金券不存在',
            icon: 'loading',
            duration: 1000,
            mask: true
          })
        }
      }
    })
  }
})