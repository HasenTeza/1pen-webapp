var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  //名字
  getName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  //电话
  getPhone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  //申请说明
  bindinput: function (e) {
    this.setData({
      input: e.detail.value
    })
  },
  btn: function () {
    var that = this

    if (!that.data.name) {
      wx.showToast({
        title: '请输入姓名',
      });
    } else if (!that.data.phone) {
      wx.showToast({
        title: '请输入电话',
      });
    } else if (!that.data.input) {
      wx.showToast({
        title: '请输入审请说明',
      });
    } else {
      var postData = {
        bis_id: app.globalData.bis_id,
        name: that.data.name,
        mobile: that.data.phone,
        pro_detail: that.data.input,
      }
      console.log(postData)
      wx.request({
        url: app.globalData.requestUrl + '/index/Supplier/addSupplier',
        header: {
          'content-type': ''
        },
        method: 'POST',
        data: postData,
        success: function (res) {
          console.log(res)
          if (res.data.statuscode == 1) {
            // console.log('111')
            wx.showToast({
              title: '提交成功',
              icon: 'success',
              duration: 2000,
              mask: true,
              success: function () {
                wx.reLaunch({
                  url: '/pages/m_index/index',
                })
              }
            })
          }
        }
      })
    }


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})