var app = getApp()
Page({

  data: {

  },

  onLoad: function (options) {
    //将字符串转换成对象
    var bean = JSON.parse(options.model);
    if (options.model == null) {
      wx.showToast({
        title: '数据为空',
      })
      return;
    }
    this.setData({
      model: bean,
      orderid: options.orderid
    })
    console.log(options.orderid)

    var that = this
    var postdata = {
      order_id: options.orderid
    }
    that.getOrderInfo(postdata)

  },


  //获取订单信息
  getOrderInfo: function (postdata) {
    var that = this
    wx.request({
      url: app.globalData.requestUrl + '/index/order/getOrderDetailInfo',
      data: postdata,
      method: 'post',
      header: {
        'content-type': ''
      },
      success: function (res) {
        console.log(res,'订单信息')
        if (res.data.statuscode == 1) {
          that.setData({
            order_info: res.data.result
          })
          // console.log(res.data.result)
        } else {
          that.setData({
            order_info: []
          })
        }

        //自提信息
        that.setData({
          ziti_content: res.data.result.mention_id
        })


        //获取其他购买者的头像
        wx.request({
          url: app.globalData.requestUrl + '/index/order/getOrderInfoUrl',
          data: {
            order_no: res.data.result.order_no,
            bis_id:app.globalData.bis_id
          },
          method: 'post',
          header: {
            'content-type': ''
          },
          success: function (res) {
            console.log(res,'其他购买用户信息')
            that.setData({
              imgs:res.data.result
            })
          }
        })

      }
    })
  },
  //分享
  onShareAppMessage: function () {
    var orderid = this.data.orderid
    var name = app.globalData.userInfo.nickName
    // console.log(this.data.tz_id)
    return {
      title: '我是' + name + '，我在参加接龙团购' ,
      path: 'pages/community/community?orderid=' + orderid // 路径，传递参数到指定页面。

    }

  },
})