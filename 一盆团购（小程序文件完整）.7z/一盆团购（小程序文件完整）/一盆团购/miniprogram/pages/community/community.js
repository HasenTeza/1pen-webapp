var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tz_id: '',
    cart: '0',
    page: 1,
    group_id: '',
    tcStatus: true,
    countDownDay: '00',
    countDownHour: '00',
    countDownMinute: '00',
    countDownSecond: '00',
    hideModal: true, //模态框的状态  true-隐藏  false-显示
    animationData: {},//
    imglist: ['http://demo.sc.chinaz.com/Files/DownLoad/webjs1/201801/jiaoben5647/img/5.jpg', 'http://demo.sc.chinaz.com/Files/DownLoad/webjs1/201801/jiaoben5647/img/1.jpg', 'http://demo.sc.chinaz.com/Files/DownLoad/webjs1/201801/jiaoben5647/img/2.jpg']

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var bis_id = app.globalData.bis_id

    // var tz_id = options.tz_id
    // console.log(options)
    // console.log(options.tz_id)
    //转发时的团长id
    if (options.tz_id) {
      that.setData({
        tz_id_zhuanfa: options.tz_id
      })
      // wx.request({
      //   url: app.globalData.requestUrl + '/index/mention/getMentionInfoRush',
      //   data: {
      //     bis_id: app.globalData.bis_id,
      //     mention_id: e.currentTarget.dataset.menction_id,
      //     mem_id: app.globalData.openid
      //   },
      //   method: 'post',
      //   header: {
      //     'content-type': ''
      //   },
      //   success: function (res) {
      //     console.log(app.globalData.bis_id, e.currentTarget.dataset.menction_id, app.globalData.openid)
      //     console.log(res)

      //   }
      // })
      app.globalData.tz_id = options.tz_id
    }
    //获取活动id
    wx.request({
      url: app.globalData.requestUrl + '/index/RushGroup/getGroupRush',
      data: {
        bis_id: app.globalData.bis_id,
      },
      header: {
        'content-type': ''
      },
      method: 'post',
      success: function (res) {
        // console.log(res.data.result.group_id, '获取活动id')
        that.setData({
          group_id: res.data.result.group_id
        })

      }
    })


    //支付完成的的人分享订单跳页面时选择的团长id
    if (app.globalData.tz_id1) {
      console.log(app.globalData.tz_id1)
      that.setData({
        tz_id: app.globalData.tz_id1
      })
    }


    if (that.data.tcStatus) {
      // 显示加载图标
      wx.showLoading({
        title: '玩命加载中',
        textStyle: {
          fontSize: 20,
          color: 'red'
        }
      })
    }
    // 获取userinfo
    wx.login({
      success: function (res) {
        if (res.code) {
          wx.getUserInfo({
            withCredentials: false,
            success: function (data) {
              //将userInfo存入缓存
              // console.log(data)
              wx.setStorage({
                key: "userInfo",
                data: data.userInfo
              })
              app.globalData.userInfo = data.userInfo
              that.getOpenid(options)

            },
            fail: function () {
            }
          });
        }
      }
    })

  },
  /**
 * 生命周期函数--监听页面显示
 */
  onShow: function () {
    var that = this
    //获取页面数据
    // that.pageData()
    //用户不是通过团长分享进来时
    // if (!app.globalData.tz_id) {
    //   wx.navigateTo({
    //     url: '/pages/tuanzhang_dz/tuanzhang_dz',
    //   })
    // } else {
    //   that.setData({
    //     tz_id: app.globalData.tz_id
    //   })
    // }
    if (that.data.tcStatus) {
      // 显示加载图标
      wx.showLoading({
        title: '玩命加载中',
        textStyle: {
          fontSize: 20,
          color: 'red'
        }
      })
    }
    // 获取userinfo
    wx.login({
      success: function (res) {
        if (res.code) {
          wx.getUserInfo({
            withCredentials: false,
            success: function (data) {
              //将userInfo存入缓存
              // console.log(data)
              wx.setStorage({
                key: "userInfo",
                data: data.userInfo
              })
              app.globalData.userInfo = data.userInfo
              that.getOpenid()

            },
            fail: function () {
            }
          });
        }
      }
    })
  },

  //-------------------------------------------------------
  

  //------------------------------------------



  // 获取openid
  getOpenid: function (options) {
    // console.log(app.globalData.userInfo)

    var that = this
    var userInfo = app.globalData.userInfo
    var userinfo = {
      avatarUrl: userInfo.avatarUrl,
      city: userInfo.city,
      country: userInfo.country,
      gender: userInfo.gender,
      nickName: userInfo.nickName,
      province: userInfo.province
    }
    // console.log(userInfo)
    //调用登录接口
    wx.login({
      success: function (res) {
        var postdata = {
          appid: app.globalData.appid,
          secret: app.globalData.secret,
          code: res.code,
          bis_id: app.globalData.bis_id,
          avatarUrl: userInfo.avatarUrl,
          city: userInfo.city,
          country: userInfo.country,
          gender: userInfo.gender,
          nickName: userInfo.nickName,
          province: userInfo.province
        }
        wx.request({

          url: app.globalData.requestUrl + '/index/index/getOpenIdNew',
          data: postdata,
          header: {
            'content-type': ''
          },
          method: 'POST',
          success: function (res) {
            // console.log(res, 'openid1111111')
            app.globalData.openid = res.data.openid

            if (!res.data.openid) {
              that.getOpenId()


            } else {
              that.setData({
                tcStatus: false
              })
              if (!that.data.tcStatus) {
                wx.hideLoading();
                // 隐藏加载框
              }
              //获取页面数据
              that.pageData()
              //将openid存入缓存
              wx.setStorage({
                key: "openid",
                data: res.data.openid
              })
            }
            //获取购物车信息给购物车navbar加上角标
            wx.request({
              url: app.globalData.requestUrl + '/index/shoppingcart/getShoppingCartInfo',
              data: {
                bis_id: app.globalData.bis_id,
                wx_id: app.globalData.openid
              },
              header: {
                'content-type': ''
              },
              method: 'post',
              success: function (res) {
                // console.log(res, '获取购物车信息')
                if (!res.data.result) return
                var num = String(res.data.result.length)
                // console.log(num)
                wx.setTabBarBadge({
                  index: 3,
                  text: num
                })

              }
            })
          }
        })

      }
    })
  },
  //获取倒计时时间及商品信息
  pageData: function () {
    var that = this
    var bis_id = app.globalData.bis_id
    // console.log(app.globalData.bis_id, app.globalData.openid)
    //获取商品和倒计时
    wx.request({
      url: app.globalData.requestUrl + '/index/mention/getTime',
      data: {
        bis_id: app.globalData.bis_id,
        mem_id: app.globalData.openid,
        group_id: that.data.group_id
      },
      method: 'GET',
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res.data.result.time.start_time)
        // console.log(res.data.result.time.stop_time)
        console.log(res.data.result, '获取商品信息')
        that.setData({
          content: res.data.result
        })
        that.countDown(res.data.result.time.stop_time)
        // wx.setNavigationBarTitle({
        //   title: res.data.result.time.title
        // })
      }
    })

    //获取接龙订单信息
    wx.request({
      url: app.globalData.requestUrl + '/index/order/getOrderInfoBuy',
      data: {
        bis_id: app.globalData.bis_id,
        group_id: that.data.group_id,
        page: that.data.page
      },
      method: 'POST',
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res.data.result, '接龙订单信息')
        that.setData({
          dd: res.data.result
        })
      }
    })



    //获取banner
    wx.request({
      url: app.globalData.requestUrl + '/index/index/getBannerInfoBuy?bis_id=' + bis_id,
      method: 'GET',
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res.data.result[0])
        that.setData({
          banner: res.data.result[0]
        })
      }
    })


    if (!app.globalData.tz_id1) {

      

      //获取时候选择过团长
      wx.request({
        url: app.globalData.requestUrl + '/index/mention/getMentionOld',
        data: {
          bis_id: app.globalData.bis_id,
          mem_id: app.globalData.openid
        },
        method: 'POST',
        header: {
          'content-type': ''
        },
        success: function (res) {
          // console.log(app.globalData.bis_id, app.globalData.openid)
          console.log(res, '获取选择过的团长信息')
          //逻辑处理：1.当获取团长id不为0时就传入数据库 调取获取团长信息接口
          //         2.为0时，就跳转修改页面，修改app中tz_id值回来在获取openid下的团长id请求信息
          if (that.data.tz_id) {
            console.log('用户之前选择过或者接受分享过')
            if (that.data.tz_id_zhuanfa) {    //新增参数判断接受分享时的tz_id

              that.setData({
                tz_id: that.data.tz_id_zhuanfa,
                tz_id_zhuanfa:''
              })
              that.data.tz_id_zhuanfa == ''
            }else{
              // console.log(res.data.result.menction_id,that.data.tz_id)
              if (res.data.result.menction_id !== that.data.tz_id) {
                that.setData({
                  tz_id: res.data.result.menction_id
                })
              }
            }
            
            that.tz_xx()
          } else if (res.data.result.menction_id > 0) {
            // console.log('用户选择团长时')
            
            // if (app.globalData.tz_id){
            //   that.setData({
            //     tz_id: app.globalData.tz_id
            //   })
            // }else{
              that.setData({
                tz_id: res.data.result.menction_id
              })
            // }
            // app.globalData.tz_id = res.data.result.menction_id
            // console.log(that.data.tz_id, app.globalData.tz_id, res.data.result.menction_id)
            that.tz_xx()
          } else if (that.data.tz_id == '') {
            console.log('用户没有分享没有选择地址时')
            if (!app.globalData.tz_id) {
              wx.navigateTo({
                url: '/pages/tuanzhang_dz/tuanzhang_dz',
              })
            } else {
              console.log('1')
              that.setData({
                tz_id: app.globalData.tz_id
              })
            }
            that.tz_xx()

          }

          that.zje()

          that.tianjia(that.data.group_id)
        }
      })
    } else {
      that.zje()
    cosn.log('1')
      that.tz_xx()
      that.tianjia(that.data.group_id)

      app.globalData.tz_id1 = ''
    }

  },
  //获取总金额
  zje: function () {
    var that = this
    var bis_id = app.globalData.bis_id
    //获取总金额
    wx.request({
      url: app.globalData.requestUrl + '/index/shoppingcart/getSelectedRushTotalPrice',
      method: 'POST',
      data: {
        bis_id: bis_id,
        wx_id: app.globalData.openid,
        mention_id: that.data.tz_id,
        group_id: that.data.group_id
      },
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(bis_id, app.globalData.openid, that.data.tz_id)
        // console.log(res, '获取总金额')
        // console.log(res.data.result,'获取总金额')
        that.setData({
          allMoney: res.data.result
        })
      }
    })
  },
  //获取团长信息
  tz_xx: function () {
    var that = this
    var bis_id = app.globalData.bis_id
    wx.request({
      url: app.globalData.requestUrl + '/index/mention/getMentionSolitaire',
      method: 'GET',
      data: {
        bis_id: bis_id,
        mem_id: app.globalData.openid,
        mention_id: that.data.tz_id
      },
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(bis_id, app.globalData.openid, that.data.tz_id)
        console.log(res, '获取团长')
        that.setData({
          tuanzhang: res.data.result,
          tuanzhang_url: res.data.url
        })
      }
    })
  },
  //切换团长
  huantuan: function () {
    wx.navigateTo({
      url: '/pages/tuanzhang_dz/tuanzhang_dz',
    })
  },
  //点击进入详情页面
  details: function (e) {
    // console.log(e.currentTarget.dataset.pro_id)
    var pro_id = e.currentTarget.dataset.pro_id;
    wx.navigateTo({
      url: '/pages/pro_detail/pro_detail?pro_id=' + pro_id + '&jielong=true',
    })
  },



  //倒计时
  countDown: function (time1) {
    //计算倒计时
    var totalSecond = time1 - Date.parse(new Date()) / 1000;
    var interval = setInterval(function () {
      // 秒数
      var second = totalSecond;

      // 天数位
      var day = Math.floor(second / 3600 / 24);
      var dayStr = day.toString();
      if (dayStr.length == 1) dayStr = '0' + dayStr;

      // 小时位
      var hr = Math.floor((second - day * 3600 * 24) / 3600);
      var hrStr = hr.toString();
      if (hrStr.length == 1) hrStr = '0' + hrStr;

      // 分钟位
      var min = Math.floor((second - day * 3600 * 24 - hr * 3600) / 60);
      var minStr = min.toString();
      if (minStr.length == 1) minStr = '0' + minStr;

      // 秒位
      var sec = second - day * 3600 * 24 - hr * 3600 - min * 60;
      var secStr = sec.toString();
      if (secStr.length == 1) secStr = '0' + secStr;
      // console.log(dayStr,hrStr,minStr,secStr,'倒计时')
      this.setData({
        countDownDay: dayStr,
        countDownHour: hrStr,
        countDownMinute: minStr,
        countDownSecond: secStr,
      });
      totalSecond--;
      if (totalSecond < 0) {
        clearInterval(interval);
        wx.showToast({
          title: '活动已结束',
        });

        this.setData({
          countDownDay: '00',
          countDownHour: '00',
          countDownMinute: '00',
          countDownSecond: '00',
        });
      }
    }.bind(this), 1000);
  },

  // 显示遮罩层    已选按钮
  showModal: function (e) {
    var that = this;
    this.setData({
      group_id: e.currentTarget.dataset.group_id
    })
    //获取选中商品信息
    that.tianjia(e.currentTarget.dataset.group_id)

    that.setData({
      hideModal: false
    })
    var animation = wx.createAnimation({
      duration: 200,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    this.animation = animation
    setTimeout(function () {
      that.fadeIn();//调用显示动画
    }, 200)
  },

  // 隐藏遮罩层
  hideModal: function () {
    var that = this;
    var animation = wx.createAnimation({
      duration: 400,//动画的持续时间 默认400ms   数值越大，动画越慢   数值越小，动画越快
      timingFunction: 'ease',//动画的效果 默认值是linear
    })
    this.animation = animation
    that.fadeDown();//调用隐藏动画   
    setTimeout(function () {
      that.setData({
        hideModal: true
      })
    }, 320)//先执行下滑动画，再隐藏模块

  },

  //动画集
  fadeIn: function () {
    this.animation.translateY(0).step()
    this.setData({
      animationData: this.animation.export()//动画实例的export方法导出动画数据传递给组件的animation属性
    })
  },
  fadeDown: function () {
    this.animation.translateY(500).step()
    this.setData({
      animationData: this.animation.export(),
    })
  },
  shoppingCart: function (e) {
    console.log(e.currentTarget.dataset.group_id)
    app.globalData.group_id = e.currentTarget.dataset.group_id
    app.globalData.groupStatus = false
    wx.switchTab({
      url: '/pages/shoppingCart/shoppingcart',
    })
  },
  //图片预览
  // previewImage: function (e) {
  //   var current = e.target.dataset.src;
  //   console.log(current)
  //   wx.previewImage({
  //     current: current, // 当前显示图片的http链接  
  //     urls: this.data.imglist // 需要预览的图片http链接列表  
  //   })
  // },

  //去支付
  pay: function (e) {
    // console.log(e.currentTarget.dataset.group_id)
    wx.navigateTo({
      url: '../confirm_order/confirm_order?group_id=' + e.currentTarget.dataset.group_id,
    })
  },
  // 获取已添加商品
  tianjia: function (group_id) {
    var that = this;
    //获取选中商品信息
    var postdata = {
      bis_id: app.globalData.bis_id,
      openid: app.globalData.openid,
      group_id: group_id,
      cart: that.data.cart,
    }
    wx.request({
      url: app.globalData.requestUrl + '/index/shoppingcart/getSelectedRushCartInfo',
      method: 'POST',
      data: postdata,
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res, '选中商品信息')
        that.setData({
          showData: res.data.result.pro_info
        })
        //当没有选中商品的时候
        if (res.data.result.pro_info.length <= 0) {

          that.hideModal()
          that.setData({
            loginStatus: false
          })
        } else {
          that.setData({
            loginStatus: true
          })
        }
      }
    })
  },
  //预览商品删除
  shanchu: function (e) {
    var that = this
    // console.log(e.currentTarget.dataset.cart_id)
    wx.request({
      url: app.globalData.requestUrl + '/index/shoppingcart/deleteRushCartById',
      method: 'POST',
      data: {
        cart_id: e.currentTarget.dataset.cart_id
      },
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res, '删除预览商品')
        that.tianjia(that.data.group_id)
        that.pageData()
      }
    })
  },


  //商品减1
  subtract: function (e) {
    console.log(e.currentTarget.dataset.count)
    if (e.currentTarget.dataset.count <= 0) return
    var that = this

    var postdata = {
      bis_id: app.globalData.bis_id,
      count: e.currentTarget.dataset.count - 1,
      pro_id: e.currentTarget.dataset.con_id,
      mem_id: app.globalData.openid,
      group_id: e.currentTarget.dataset.group_id,
      mention_id: that.data.tz_id,
    }
    wx.request({
      url: app.globalData.requestUrl + '/index/shoppingcart/addProIntoRushCart',
      method: 'POST',
      data: postdata,
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res.data.result)

        that.pageData()
        that.tianjia(that.data.group_id)
      }
    })
  },
  //商品加1
  add: function (e) {
    var that = this
    var postdata = {
      bis_id: app.globalData.bis_id,
      count: e.currentTarget.dataset.count + 1,
      pro_id: e.currentTarget.dataset.con_id,
      mem_id: app.globalData.openid,
      group_id: e.currentTarget.dataset.group_id,
      mention_id: that.data.tz_id,
    }
    console.log(postdata)
    wx.request({
      url: app.globalData.requestUrl + '/index/shoppingcart/addProIntoRushCart',
      method: 'POST',
      data: postdata,
      header: {
        'content-type': ''
      },
      success: function (res) {
        // console.log(res)

        that.pageData()
        that.tianjia(that.data.group_id)
      }
    })

  },

  /**
      * 生命周期函数--监听页面初次渲染完成
      */
  onReady: function () {
    if (!app.globalData.userInfo || app.globalData.userInfo == '') {


    }
    wx: wx.getSetting({
      success: function (res) {
        // console.log(res.authSetting['scope.userInfo'])
        if (res.authSetting['scope.userInfo']) {
          // console.log('授权了')
        } else {

          wx.reLaunch({
            url: '/pages/first/first?url1=' + '/pages/community/community',
          })
          // console.log('没有授权给个弹框让他授权')
        }

      }
    })
  },
  //分享
  onShareAppMessage: function () {
    var name = app.globalData.userInfo.nickName
    // console.log(this.data.tz_id)
    return {
      title: '我是' + name + '，正在接龙团购，实在忍不住和你分享！',
      path: 'pages/community/community?tz_id=' + this.data.tz_id // 路径，传递参数到指定页面。

    }

  },


  onReachBottom: function () {    //上拉事件
    var that = this;

    // 显示加载图标
    wx.showLoading({
      title: '玩命加载中',
    })
    // 页数+1
    var page = this.data.page;
    page++;
    //更改data
    that.setData({
      page: page
    })


    wx.request({
      url: app.globalData.requestUrl + '/index/order/getOrderInfoBuy',
      data: {
        bis_id: app.globalData.bis_id,
        group_id: '6',
        page: that.data.page
      },
      method: 'POST',
      header: {
        'content-type': ''
      },
      success: function (res) {

        // console.log(that.data.page)
        //定义数组
        var dd_data_list = that.data.dd;
        // console.log(res.data)
        // console.log(res.data.result)
        // console.log(res.data.result.length)
        if (res.data.result) {
          for (var i = 0; i < res.data.result.length; i++) {
            //添加新的
            dd_data_list.push(res.data.result[i]);
          }

          // 设置数据
          that.setData({
            dd: dd_data_list
          })
          console.log(that.data.dd, '上拉加载')
          // 隐藏加载框
          wx.hideLoading();
          wx.stopPullDownRefresh()
        } else {
          // 隐藏加载框
          wx.hideLoading();
          wx.stopPullDownRefresh()
        }

      }
    })

  }
})