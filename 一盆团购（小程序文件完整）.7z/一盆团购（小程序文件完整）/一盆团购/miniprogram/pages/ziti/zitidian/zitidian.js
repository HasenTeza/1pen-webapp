// pages/ziti/zitidian/zitidian.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    wx.request({
      url: app.globalData.requestUrl+'/index/mention/getAllMentionInfo',
      data: { 
        bis_id: app.globalData.bis_id
       },
      method: 'post',
      header: {
        'content-type': ''
      },
      success: function (res) {
        console.log(res.data.result,'自提点信息')
        that.setData({
          zitidian: res.data.result
        })
      }
    })
  },
  btn:function(e){
    console.log(e.currentTarget.dataset.menction_id)
    wx.request({
      url: app.globalData.requestUrl + '/index/mention/getMentionCheck',
      data: {
        menction_id: e.currentTarget.dataset.menction_id,
        openid:app.globalData.openid
      },
      method: 'post',
      header: {
        'content-type': ''
      },
      success: function (res) {
        console.log(res.data.result[0])
        var pages = getCurrentPages(); // 获取页面栈
        var currPage = pages[pages.length - 1]; // 当前页面
        var prevPage = pages[pages.length - 2]; // 上一个页面
        prevPage.setData({
          ziti_content: res.data.result[0]
        })
        wx.navigateBack({
          delta: 1
        })
      }
    })
  
  }
})