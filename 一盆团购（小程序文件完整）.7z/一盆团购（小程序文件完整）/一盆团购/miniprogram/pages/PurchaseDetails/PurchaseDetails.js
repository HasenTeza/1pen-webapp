var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var order_no = options.order_no
    // var order_no = '19011016501600036476'
    wx.request({
      url: app.globalData.requestUrl +'/index/order/getOrderDetailInfoRush',
      data: {
        order_id: order_no
      },
      method: 'post',
      header: {
        'content-type': ''
      },
      success: function (res) {
        
        that.setData({
          main_order: res.data.result.main_order,
          images: res.data.result.member,
          pro_info: res.data.result.pro_info,
          tz_id: res.data.result.main_order.mention_id
        })
      }
    })
  },
  pay:function(){
    app.globalData.tz_id1 = this.data.tz_id
    wx.switchTab({
      url: '/pages/community/community',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})