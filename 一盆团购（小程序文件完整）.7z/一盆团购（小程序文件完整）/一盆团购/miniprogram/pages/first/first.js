var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    sq_xs: true, //根据用户是否授权改变状态
    sq_zhengti: true, //用户授权成功整个哲罩层消失
    //判断小程序的API，回调，参数，组件等是否在当前版本可用。
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    
  
    if (options.url || options.pro_id || options.order_id){
      this.setData({
        url: options.url,
        pro_id: options.pro_id,
        order_id: options.order_id
      })
    }
    if (options.url1){
      this.setData({
        url1: options.url1,
      })
    }
  },
  aa: function () {
    this.setData({
      'sq_xs': false
    })
  },
  bindGetUserInfo: function (e) {
    var that = this
    if (e.detail.userInfo) {
     

      wx: wx.setStorage({
        key: 'userInfo',
        data: e.detail.userInfo,
      })
      app.globalData.userInfo = e.detail.userInfo
      console.log(e.detail.userInfo, '授权后更新app.js的userInfo')
      // 获取userinfo
      wx.login({
        success: function (res) {
          if (res.code) {
            wx.getUserInfo({
              withCredentials: false,
              success: function (data) {
                //将userInfo存入缓存
                wx.setStorage({
                  key: "userInfo",
                  data: data.userInfo
                })
                app.globalData.userInfo = data.userInfo
                that.getOpenid()
              },
              fail: function () {
              }
            });
          }
        }
      })
      if (this.data.url && this.data.pro_id){
        wx.reLaunch({
          url: this.data.url + '?pro_id=' + this.data.pro_id,
        })
      } else if (this.data.order_id){
        wx.reLaunch({
          url: this.data.url + '?order_id=' + this.data.order_id,
        })
      } else if (this.data.url1){
        wx.reLaunch({
          url: this.data.url1,
        })
      }else{
        wx.switchTab({
          url: '../m_index/index', //注意switchTab只能跳转到带有tab的页面，不能跳转到不带tab的页面
        })
      }
      

    } else {
      //用户按了拒绝按钮
      console.log('没授权')
      this.setData({
        'sq_xs': true
      })
    }
  },
  // 获取openid
  getOpenid: function (options) {
    console.log(app.globalData.userInfo)

    var that = this
    var userInfo = app.globalData.userInfo
    var userinfo = {
      avatarUrl: userInfo.avatarUrl,
      city: userInfo.city,
      country: userInfo.country,
      gender: userInfo.gender,
      nickName: userInfo.nickName,
      province: userInfo.province
    }
    // console.log(userInfo)
    //调用登录接口
    wx.login({
      success: function (res) {
        var postdata = {
          appid: app.globalData.appid,
          secret: app.globalData.secret,
          code: res.code,
          bis_id: app.globalData.bis_id,
          avatarUrl: userInfo.avatarUrl,
          city: userInfo.city,
          country: userInfo.country,
          gender: userInfo.gender,
          nickName: userInfo.nickName,
          province: userInfo.province
        }
        wx.request({

          url: app.globalData.requestUrl + '/index/index/getOpenIdNew',
          data: postdata,
          header: {
            'content-type': ''
          },
          method: 'POST',
          success: function (res) {
            console.log(res, 'openid1111111')
            app.globalData.openid = res.data.openid
            // console.log('res',res)
            if (!res.data.openid) {
              that.getOpenId()
            } else {
              //将openid存入缓存
              wx.setStorage({
                key: "openid",
                data: res.data.openid
              })
            }
            // //获取购物车信息给购物车navbar加上角标
            // wx.request({
            //   url: app.globalData.requestUrl + '/index/shoppingcart/getShoppingCartInfo',
            //   data: {
            //     bis_id: app.globalData.bis_id,
            //     wx_id: app.globalData.openid
            //   },
            //   header: {
            //     'content-type': ''
            //   },
            //   method: 'post',
            //   success: function (res) {
            //     // console.log(res, '获取购物车信息')
            //     if (!res.data.result) return
            //     var num = String(res.data.result.length)
            //     // console.log(num)
            //     wx.setTabBarBadge({
            //       index: 3,
            //       text: num
            //     })

            //   }
            // })
          }
        })

      }
    })
  },

})